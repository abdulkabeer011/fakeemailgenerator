require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("./config/db");

const Email = require("./models/Email");

const app = express();
app.use(cors());
app.use(express.json());

// Generate Random Fake Email
app.get("/generate-email", async (req, res) => {
    const randomString = Math.random().toString(36).substring(2, 10);
    const fakeEmail = `${randomString}@tempmail.dev`;
    
    const newEmail = new Email({ email: fakeEmail });
    await newEmail.save();
    
    res.json({ email: fakeEmail });
});

// Fetch Inbox (Dummy API)
app.get("/inbox/:email", async (req, res) => {
    res.json({ messages: [`Test email received for ${req.params.email}`] });
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
