const mongoose = require("mongoose");

const emailSchema = new mongoose.Schema({
  email: String,
  createdAt: { type: Date, expires: 600, default: Date.now } // Auto-delete after 10 minutes
});

module.exports = mongoose.model("Email", emailSchema);
